import { getDirectChildRecords } from "./calculations";
import {
  findTopLevelStowedContainerRecords,
  isCharacterLikeEntity,
} from "./validation";
import { getRecordHandsRequired, normalizeHandsRequired } from "./types";
import type {
  ArmorData,
  CoinData,
  ContainerBurdenMode,
  ContainerData,
  Entity,
  EntityId,
  HandsRequired,
  IdentificationData,
  InventoryBurden,
  InventoryLocation,
  InventoryRecord,
  InventoryRecordId,
  InventoryRecordType,
  LightData,
  Modifier,
  UsesData,
  WeaponData,
} from "./types";

export type InventoryRecordPlacementKey =
  | "default"
  | "equippedLoose"
  | "leftHand"
  | "rightHand"
  | "bothHands"
  | "coinPurse"
  | "stowedRoot"
  | "contents"
  | "container";

export type InventoryRecordLocationInput = {
  entityId: EntityId;
  placement: InventoryRecordPlacementKey;
  containerId?: InventoryRecordId;
};

export type InventoryRecordFormInput = {
  recordType: InventoryRecordType;
  name?: string;
  description?: string;
  coins?: Partial<CoinData>;
  gpValue?: number;
  weapon?: Partial<WeaponData>;
  armor?: Partial<ArmorData>;
  quantity?: number;
  burden?: InventoryBurden;
  container?: Partial<ContainerData>;
  handsRequired?: HandsRequired;
  identification?: Partial<IdentificationData>;
  uses?: Partial<UsesData>;
  light?: Partial<LightData>;
  modifiers?: Modifier[];
  notes?: string;
  location?: InventoryRecordLocationInput;
};

export type CreateInventoryRecordInput = {
  entity: Entity;
  id: InventoryRecordId;
  records: InventoryRecord[];
  input: InventoryRecordFormInput;
};

export type UpdateInventoryRecordInput = {
  record: InventoryRecord;
  records: InventoryRecord[];
  entity: Entity;
  input: InventoryRecordFormInput;
};

export type MoveInventoryRecordInput = {
  recordId: InventoryRecordId;
  records: InventoryRecord[];
  entityId: EntityId;
  location: InventoryLocation;
};

export type InventoryRecordBuildResult =
  | { ok: true; record: InventoryRecord }
  | { ok: false; message: string };

export type InventoryLocationBuildResult =
  | { ok: true; location: InventoryLocation }
  | { ok: false; message: string };

const EMPTY_COINS: CoinData = {
  pp: 0,
  gp: 0,
  sp: 0,
  cp: 0,
};

export function createInventoryRecordFromInput({
  entity,
  id,
  records,
  input,
}: CreateInventoryRecordInput): InventoryRecordBuildResult {
  const locationResult = createInventoryLocation({
    entity,
    recordType: input.recordType,
    records,
    location: input.location,
    isContainer: Boolean(input.container),
  });

  if (!locationResult.ok) {
    return locationResult;
  }

  const sortOrder = getNextInventoryRecordSortOrder(
    records,
    entity.id,
    locationResult.location,
  );

  return buildInventoryRecord({
    id,
    entityId: entity.id,
    input,
    location: locationResult.location,
    sortOrder,
  });
}

export function updateInventoryRecordFromInput({
  record,
  records,
  entity,
  input,
}: UpdateInventoryRecordInput): InventoryRecordBuildResult {
  if (record.recordType !== input.recordType) {
    return {
      ok: false,
      message: "Inventory record type cannot be changed while editing.",
    };
  }

  const locationResult = createInventoryLocation({
    entity,
    recordType: input.recordType,
    records,
    location: input.location,
    isContainer: Boolean(input.container),
    editingRecordId: record.id,
  });

  if (!locationResult.ok) {
    return locationResult;
  }

  return buildInventoryRecord({
    id: record.id,
    entityId: entity.id,
    input: {
      ...input,
      handsRequired: input.handsRequired ?? getRecordHandsRequired(record),
    },
    location: locationResult.location,
    sortOrder: record.sortOrder,
  });
}

export function createInventoryLocation({
  entity,
  recordType,
  records,
  location,
  isContainer,
  editingRecordId,
}: {
  entity: Entity;
  recordType: InventoryRecordType;
  records: InventoryRecord[];
  location?: InventoryRecordLocationInput;
  isContainer?: boolean;
  editingRecordId?: InventoryRecordId;
}): InventoryLocationBuildResult {
  const placement = location?.placement ?? "default";

  if (recordType === "coins") {
    if (isCharacterLikeEntity(entity)) {
      return {
        ok: true,
        location: {
          kind: "coinPurse",
        },
      };
    }

    if (placement === "container") {
      const containerIdResult = getUsableContainerId({
        entity,
        records,
        containerId: location?.containerId,
        isContainer: false,
        editingRecordId,
      });

      if (!containerIdResult.ok) {
        return containerIdResult;
      }

      return {
        ok: true,
        location: {
          kind: "container",
          containerId: containerIdResult.containerId,
        },
      };
    }

    return {
      ok: true,
      location: {
        kind: "contents",
      },
    };
  }

  if (!isCharacterLikeEntity(entity)) {
    if (placement === "container") {
      const containerIdResult = getUsableContainerId({
        entity,
        records,
        containerId: location?.containerId,
        isContainer,
        editingRecordId,
      });

      if (!containerIdResult.ok) {
        return containerIdResult;
      }

      return {
        ok: true,
        location: {
          kind: "container",
          containerId: containerIdResult.containerId,
        },
      };
    }

    return {
      ok: true,
      location: {
        kind: "contents",
      },
    };
  }

  switch (placement) {
    case "leftHand":
    case "rightHand":
    case "bothHands":
      return {
        ok: true,
        location: {
          kind: "equipped",
          placement,
        },
      };
    case "stowedRoot": {
      if (!isContainer) {
        return {
          ok: false,
          message: "Only containers can be placed as the stowed root.",
        };
      }

      const existingStowedRoot = findTopLevelStowedContainerRecords(
        entity.id,
        records,
      ).find((record) => record.id !== editingRecordId);

      if (existingStowedRoot) {
        return {
          ok: false,
          message: "This entity already has a stowed container.",
        };
      }

      return {
        ok: true,
        location: {
          kind: "stowedRoot",
        },
      };
    }
    case "container": {
      const containerIdResult = getUsableContainerId({
        entity,
        records,
        containerId: location?.containerId,
        isContainer,
        editingRecordId,
      });

      if (!containerIdResult.ok) {
        return containerIdResult;
      }

      return {
        ok: true,
        location: {
          kind: "container",
          containerId: containerIdResult.containerId,
        },
      };
    }
    case "default":
    case "equippedLoose":
    case "coinPurse":
    case "contents":
      return {
        ok: true,
        location: {
          kind: "equipped",
          placement: "loose",
        },
      };
  }
}

export function moveInventoryRecord({
  recordId,
  records,
  entityId,
  location,
}: MoveInventoryRecordInput): InventoryRecord[] {
  const record = records.find(
    (candidateRecord) => candidateRecord.id === recordId,
  );

  if (!record) {
    return records;
  }

  const descendantRecordIds = getDescendantRecordIds(recordId, records);
  const sortOrder = getNextInventoryRecordSortOrder(records, entityId, location);

  return records.map((candidateRecord) => {
    if (candidateRecord.id === recordId) {
      return {
        ...candidateRecord,
        entityId,
        location,
        sortOrder,
      };
    }

    if (descendantRecordIds.has(candidateRecord.id)) {
      return {
        ...candidateRecord,
        entityId,
      };
    }

    return candidateRecord;
  });
}

export function mergeCoinData(
  currentCoins: CoinData,
  addedCoins: Partial<CoinData> | undefined,
): CoinData {
  const normalizedCoins = normalizeCoins(addedCoins);

  return {
    pp: currentCoins.pp + normalizedCoins.pp,
    gp: currentCoins.gp + normalizedCoins.gp,
    sp: currentCoins.sp + normalizedCoins.sp,
    cp: currentCoins.cp + normalizedCoins.cp,
  };
}

export function getCharacterCoinRecord(
  entityId: EntityId,
  records: InventoryRecord[],
): InventoryRecord | undefined {
  return records.find(
    (record) =>
      record.recordType === "coins" &&
      record.entityId === entityId &&
      record.location.kind === "coinPurse",
  );
}

export function isContainerRecordEmpty(
  recordId: InventoryRecordId,
  records: InventoryRecord[],
): boolean {
  return getDirectChildRecords(recordId, records).length === 0;
}

export function getMoveDescendantRecordIds(
  recordId: InventoryRecordId,
  records: InventoryRecord[],
): Set<InventoryRecordId> {
  return getDescendantRecordIds(recordId, records);
}

export function getLocationPlacementKey(
  location: InventoryLocation,
): InventoryRecordPlacementKey {
  if (location.kind === "equipped") {
    return location.placement === "loose" ? "equippedLoose" : location.placement;
  }

  return location.kind;
}

export function getUsableContainerRecords({
  editingRecordId,
  entity,
  isContainer = false,
  records,
}: {
  editingRecordId?: InventoryRecordId;
  entity: Entity;
  isContainer?: boolean;
  records: InventoryRecord[];
}): InventoryRecord[] {
  const editingDescendantRecordIds = editingRecordId
    ? getDescendantRecordIds(editingRecordId, records)
    : new Set<InventoryRecordId>();

  return records.filter(
    (record) =>
      record.id !== editingRecordId &&
      record.entityId === entity.id &&
      Boolean(record.container) &&
      isUsableContainerDepth(record, isContainer) &&
      !editingDescendantRecordIds.has(record.id),
  );
}

function buildInventoryRecord({
  id,
  entityId,
  input,
  location,
  sortOrder,
}: {
  id: InventoryRecordId;
  entityId: EntityId;
  input: InventoryRecordFormInput;
  location: InventoryLocation;
  sortOrder: number;
}): InventoryRecordBuildResult {
  const description = normalizeOptionalText(input.description);

  if (input.recordType === "coins") {
    return {
      ok: true,
      record: {
        id,
        entityId,
        recordType: "coins",
        location,
        sortOrder,
        coins: normalizeCoins(input.coins),
        ...(description ? { description } : {}),
      },
    };
  }

  const name = input.name?.trim() ?? "";

  if (name.length === 0) {
    return {
      ok: false,
      message: "Name is required.",
    };
  }

  const quantity = normalizeQuantity(input.quantity);
  const burden = normalizeBurden(input.burden);
  const container = normalizeContainer(input.container);
  const handsRequired = getInputHandsRequired(input);
  const uses = normalizeUses(input.uses);
  const light = normalizeLight(input.light);
  const modifiers = normalizeModifiers(input.modifiers);
  const notes = normalizeOptionalText(input.notes);
  const shared = {
    id,
    name,
    entityId,
    location,
    sortOrder,
    quantity,
    burden,
    handsRequired,
    ...(description ? { description } : {}),
    ...(uses ? { uses } : {}),
    ...(light ? { light } : {}),
    ...(modifiers.length > 0 ? { modifiers } : {}),
    ...(notes ? { notes } : {}),
  };
  const identification = normalizeIdentification(input.identification);

  switch (input.recordType) {
    case "treasure":
      return {
        ok: true,
        record: {
          ...shared,
          recordType: "treasure",
          treasure: {
            gpValue: normalizeNumber(input.gpValue, 0),
          },
        },
      };
    case "weapon":
      return {
        ok: true,
        record: {
          ...shared,
          ...(container ? { container } : {}),
          ...(identification ? { identification } : {}),
          recordType: "weapon",
          weapon: {
            ...(normalizeOptionalText(input.weapon?.damage)
              ? { damage: normalizeOptionalText(input.weapon?.damage) }
              : {}),
            ...(normalizeOptionalText(input.weapon?.range)
              ? { range: normalizeOptionalText(input.weapon?.range) }
              : {}),
            ...(input.weapon?.qualities && input.weapon.qualities.length > 0
              ? { qualities: normalizeQualities(input.weapon.qualities) }
              : {}),
          },
        },
      };
    case "armor":
      return {
        ok: true,
        record: {
          ...shared,
          ...(container ? { container } : {}),
          ...(identification ? { identification } : {}),
          recordType: "armor",
          armor: {
            ...(input.armor?.baseArmorClass !== undefined
              ? { baseArmorClass: normalizeNumber(input.armor.baseArmorClass, 0) }
              : {}),
            ...(input.armor?.armorBonus !== undefined
              ? { armorBonus: normalizeNumber(input.armor.armorBonus, 0) }
              : {}),
          },
        },
      };
    case "equipment":
      return {
        ok: true,
        record: {
          ...shared,
          ...(container ? { container } : {}),
          ...(identification ? { identification } : {}),
          recordType: "equipment",
        },
      };
  }
}

function getUsableContainerId({
  entity,
  records,
  containerId,
  isContainer,
  editingRecordId,
}: {
  entity: Entity;
  records: InventoryRecord[];
  containerId: InventoryRecordId | undefined;
  isContainer: boolean | undefined;
  editingRecordId: InventoryRecordId | undefined;
}): { ok: true; containerId: InventoryRecordId } | { ok: false; message: string } {
  if (!containerId) {
    return {
      ok: false,
      message: "Container placement requires a container.",
    };
  }

  const containerRecord = records.find((record) => record.id === containerId);

  if (
    !containerRecord ||
    !getUsableContainerRecords({
      entity,
      records,
      isContainer,
      editingRecordId,
    }).some((record) => record.id === containerRecord.id)
  ) {
    return {
      ok: false,
      message: "Selected container is not available.",
    };
  }

  return {
    ok: true,
    containerId: containerRecord.id,
  };
}

function isUsableContainerDepth(
  containerRecord: InventoryRecord,
  placingContainer: boolean,
): boolean {
  if (!locationHasContainerId(containerRecord.location)) {
    return true;
  }

  return !placingContainer;
}

function getNextInventoryRecordSortOrder(
  records: InventoryRecord[],
  entityId: EntityId,
  location: InventoryLocation,
): number {
  const siblingRecords = records.filter((record) =>
    record.entityId === entityId &&
    areInventoryLocationsSiblings(record.location, location),
  );

  if (siblingRecords.length === 0) {
    return 0;
  }

  return Math.max(...siblingRecords.map((record) => record.sortOrder)) + 1000;
}

function areInventoryLocationsSiblings(
  leftLocation: InventoryLocation,
  rightLocation: InventoryLocation,
): boolean {
  const leftContainerId = locationHasContainerId(leftLocation)
    ? leftLocation.containerId
    : undefined;
  const rightContainerId = locationHasContainerId(rightLocation)
    ? rightLocation.containerId
    : undefined;

  return (
    leftLocation.kind === rightLocation.kind &&
    getInventoryLocationPlacement(leftLocation) ===
      getInventoryLocationPlacement(rightLocation) &&
    leftContainerId === rightContainerId
  );
}

function getInventoryLocationPlacement(location: InventoryLocation): string {
  return location.kind === "equipped" ? location.placement : location.kind;
}

function getDescendantRecordIds(
  recordId: InventoryRecordId,
  records: InventoryRecord[],
): Set<InventoryRecordId> {
  const descendantRecordIds = new Set<InventoryRecordId>();
  const pendingRecordIds = [recordId];

  while (pendingRecordIds.length > 0) {
    const currentRecordId = pendingRecordIds.pop();

    if (!currentRecordId) {
      continue;
    }

    for (const childRecord of getDirectChildRecords(currentRecordId, records)) {
      if (!descendantRecordIds.has(childRecord.id)) {
        descendantRecordIds.add(childRecord.id);
        pendingRecordIds.push(childRecord.id);
      }
    }
  }

  return descendantRecordIds;
}

function normalizeCoins(coins: Partial<CoinData> | undefined): CoinData {
  return {
    pp: normalizeInteger(coins?.pp, EMPTY_COINS.pp),
    gp: normalizeInteger(coins?.gp, EMPTY_COINS.gp),
    sp: normalizeInteger(coins?.sp, EMPTY_COINS.sp),
    cp: normalizeInteger(coins?.cp, EMPTY_COINS.cp),
  };
}

function normalizeQuantity(quantity: number | undefined): number {
  return Math.max(1, normalizeInteger(quantity, 1));
}

function normalizeBurden(burden: InventoryBurden | undefined): InventoryBurden {
  switch (burden?.kind) {
    case "none":
      return { kind: "none" };
    case "stacked":
      return {
        kind: "stacked",
        itemsPerSlot: Math.max(1, normalizeInteger(burden.itemsPerSlot, 1)),
      };
    case "fixed":
    default:
      return {
        kind: "fixed",
        slotsPerItem: Math.max(0, normalizeNumber(burden?.slotsPerItem, 1)),
      };
  }
}

function normalizeContainer(
  container: Partial<ContainerData> | undefined,
): ContainerData | undefined {
  if (!container) {
    return undefined;
  }

  return {
    capacitySlots: Math.max(0, normalizeNumber(container.capacitySlots, 0)),
    ...(container.isBackpack ? { isBackpack: true } : {}),
    ...(container.burdenMode
      ? { burdenMode: container.burdenMode as ContainerBurdenMode }
      : {}),
  };
}

function normalizeIdentification(
  identification: Partial<IdentificationData> | undefined,
): IdentificationData | undefined {
  if (!identification) {
    return undefined;
  }

  if (identification.identified !== false) {
    return undefined;
  }

  return {
    identified: false,
    ...(normalizeOptionalText(identification.secretName)
      ? {
          secretName: normalizeOptionalText(identification.secretName),
        }
      : {}),
    ...(normalizeOptionalText(identification.secretDescription)
      ? {
          secretDescription: normalizeOptionalText(
            identification.secretDescription,
          ),
        }
      : {}),
  };
}

function normalizeUses(
  uses: Partial<UsesData> | undefined,
): UsesData | undefined {
  if (!uses) {
    return undefined;
  }

  const current = Math.max(0, normalizeInteger(uses.current, 0));
  const max =
    uses.max === undefined ? undefined : Math.max(current, normalizeInteger(uses.max, current));

  return {
    current,
    ...(max !== undefined ? { max } : {}),
  };
}

function normalizeLight(
  light: Partial<LightData> | undefined,
): LightData | undefined {
  if (!light) {
    return undefined;
  }

  return {
    isLit: light.isLit === true,
    ...(normalizeOptionalText(light.lightDescription)
      ? { lightDescription: normalizeOptionalText(light.lightDescription) }
      : {}),
  };
}

function normalizeQualities(qualities: string[]): string[] {
  return qualities
    .map((quality) => normalizeOptionalText(quality))
    .filter((quality): quality is string => Boolean(quality));
}

function normalizeModifiers(modifiers: Modifier[] | undefined): Modifier[] {
  return (modifiers ?? [])
    .map((modifier) => ({
      target: normalizeOptionalText(modifier.target) ?? "other",
      value: normalizeNumber(modifier.value, 0),
      ...(normalizeOptionalText(modifier.label)
        ? { label: normalizeOptionalText(modifier.label) }
        : {}),
    }))
    .filter((modifier) => Number.isFinite(modifier.value));
}

function getInputHandsRequired(input: InventoryRecordFormInput): HandsRequired {
  if (input.recordType === "weapon") {
    return normalizeHandsRequired(
      input.handsRequired,
      input.weapon?.hands === "twoHands" ? 2 : 1,
    );
  }

  return normalizeHandsRequired(
    input.handsRequired,
    normalizeHandsRequired(input.container?.handsRequired),
  );
}

function normalizeNumber(value: number | undefined, fallback: number): number {
  if (value === undefined || Number.isNaN(value)) {
    return fallback;
  }

  return value;
}

function normalizeInteger(value: number | undefined, fallback: number): number {
  return Math.max(0, Math.floor(normalizeNumber(value, fallback)));
}

function normalizeOptionalText(value: string | undefined): string | undefined {
  const normalizedValue = value?.trim();

  return normalizedValue && normalizedValue.length > 0
    ? normalizedValue
    : undefined;
}

function locationHasContainerId(
  location: InventoryLocation,
): location is InventoryLocation & { containerId: InventoryRecordId } {
  return "containerId" in location;
}
